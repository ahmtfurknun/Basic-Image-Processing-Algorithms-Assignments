Noisy images are produced by adding 0 mean Gaussian noise. The numbers in
the image file names after the "trin" prefix denote the noise level in dB. 

For example trin-3.pgm means -3dB of noise added to the original image.
